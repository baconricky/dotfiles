var names = document.getElementsByClassName('plugin-name');
for (var i = names.length; i--;) {
	names[i].innerHTML = p180.name;
}

document.body.style.visibility = "visible";