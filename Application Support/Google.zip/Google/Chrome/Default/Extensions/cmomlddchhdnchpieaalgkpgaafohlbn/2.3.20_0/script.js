

// keep track of active input element
var pending_message_id = 0;
var activeElement;

document.onmousedown = document.onkeydown = listener;
document.addEventListener('focus', listener, true); // focus event doesn't bubble

// broadcast selection to all other tabs
function listener(e) {
	activeElement = null;
	if (/input|textarea/i.test(document.activeElement.nodeName)) 
		activeElement = document.activeElement;
	else if (e && /input|textarea/i.test(e.target.nodeName)) 
		activeElement = e.target;

	if (activeElement) {
		pending_message_id = +new Date;
		chrome.extension.sendMessage({ name: "input_selected", id: pending_message_id  });
	} else {
		pending_message_id = 0;
		chrome.extension.sendMessage({ name: "input_deselected" });
	}
}


// listen to other tabs, last one always overwrites the others
chrome.extension.onMessage.addListener(function(message){
	//if (message.name == "input_selected") {
	//	pending_message_id = 0;
	//} 
	// uppon popup opening if ours was the last send our id
	//if (message.name == "popup_open" && pending_message_id) {
	//	chrome.extension.sendMessage({ name: "input_to_popup", id: pending_message_id });
	//} 
	// if popup sent back a face to paste
	if (message.name == "face_to_paste" && message.id == pending_message_id && activeElement) {
		 paste_face(message);
	}
});

function paste_face(message) {
	if (message.name == "face_to_paste" && message.id == pending_message_id && activeElement) {
		activeElement.focus();
		setTimeout(function(){
			var index = activeElement.selectionStart;
			activeElement.value = activeElement.value.slice(0, index) + message.face + activeElement.value.slice(index)
			activeElement.setSelectionRange(index + message.face.length, index + message.face.length);
			listener({target: activeElement});
		}, 10)
	}
}
