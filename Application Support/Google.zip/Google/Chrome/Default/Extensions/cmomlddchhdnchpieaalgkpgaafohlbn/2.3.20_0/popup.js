

var message_id;


// save active frame's message id for pasting
/*
chrome.extension.onMessage.addListener(function(message) {
	if (message.name == "input_to_popup") {
		message_id = message.id;
	}
});
chrome.extension.sendMessage({ name: "popup_open" });
*/

document.getElementById("faces").onclick = function(e) {

	if (editMode == "none" && !e.target.id) {

		// wait a bit for the selection to kick in
		setTimeout(function(){
			document.execCommand("Copy");
		}, 10)

		// if there's an input field waiting for a paste
		// let's give the face to him
		if (+localStorage.message_id)  {
			chrome.tabs.getSelected(null, function(tab) {
			  //chrome.tabs.sendMessage(tab.id, { name: "face_to_paste", id: localStorage.message_id, face: e.target.textContent });
			  chrome.tabs.executeScript({
			  	allFrames: true,
			  	code: "paste_face({name:'face_to_paste', id:" +  localStorage.message_id + ", face: '" + e.target.textContent + "'})"
			  });
			  localStorage.message_id = 0;
			  //window.close();
			  chrome.tabs.update(tab.id, { active: true }, function(){})
			});
		}
	}
};




