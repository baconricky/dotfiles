

localStorage.message_id = 0;

// listen to other tabs, last one always overwrites the others
chrome.extension.onMessage.addListener(function(message){
	if (message.name == "input_deselected") {
		localStorage.message_id = 0;
	} 
	else if (message.name == "input_selected") {
		localStorage.message_id = message.id;
	}
});


/*
// already shown before update
if (localStorage.feature_shown !== "true") {
  localStorage.feature_shown = "true";
  chrome.tabs.create({
      url: chrome.extension.getURL('feature.html'),
      selected: true
   });
}
*/