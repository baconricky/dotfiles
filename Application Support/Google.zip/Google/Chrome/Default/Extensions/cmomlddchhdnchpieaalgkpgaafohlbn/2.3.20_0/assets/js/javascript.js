//               //                   
// Configuration //
//               //

// Current version. Change this any time an update is made to the extension. Don't forget to also change this in the manifest.json file
window.version = '2.3.2';

// This is the information that will appear in the update box
window.updateInfo = "You just updated to version 2.3! There are now more suggestions, Sort and Add modes have been combined, face size can be changed, and you can now press E to toggle Edit Mode!";
    
// Default faces that will appear if no data currently exists
window.defaults = ["ಠ_ಠ", "ಠ_ರೃ", "ಥ_ಥ", "ఠ_ఠ", "﴾͡๏̯͡๏﴿", "๏_๏", "ಠ▃ಠ", "(•‿•)", "Ծ_Ծ", "¬_¬", "¯\\(°_o)/¯", "(✌ﾟ∀ﾟ)☞","╚(•⌂•)╝", "t(-_-t)", "t(ツ)_/¯", "◔_◔", "ლ(ಠ_ಠლ)", "(/ﾟДﾟ)/"];
    
// Faces that will appear in the suggestions box. Default faces will be included in this list if they were removed by the user
window.suggestions = ["(╯°□°）╯︵ ┻━┻", "(ノ^_^)ノ", "(\/)(;,,;)(\/)", "(」ﾟヘﾟ)」", "ᕦ(ò_óˇ)ᕤ", "（｀ー´）", "◎⃝ _◎⃝ ;", "ᶘ ᵒᴥᵒᶅ"];
    
// Debug mode. This will show links at the bottom of the extension for clearing localStorage or just resetting to default faces. You can also just press "D" to toggle it temporarily. MAKE SURE THIS IS SET TO 0 BEFORE RELEASING TO PUBLIC!
window.debug = 0;

//                   //
// End configuration //
//                   //



// Sections:
// 01: Document.ready
// 02: Class- face (add, del, suggestions, update, reset)
// 03: Class- edit (check, enable, disable, change)
// 04: Class- options (check, update)
// 05: Keyboard Shortcuts
// 06: Events
// 98: Debug Functions
// 99: jQuery Plugins
    
    
// Section 01: Document.ready

$("document").ready(function() {

    // This variable shouldn't be changed
    window.editMode = "none";

    // Check to see if extension was updated or hasn't been used yet
    if (localStorage['lastVersion'] == undefined || localStorage['lastVersion'] < window.version) {
	
	localStorage['hideUpdate'] = 0; // Show the update box by default again
	
	$("#update").show();
	
	localStorage['lastVersion'] = window.version; // Tell the extension it's been updated
	
    }
    
    // Show the update box if it hasn't been hidden yet
    if (localStorage['hideUpdate'] != 1) $("#update").show().prepend(window.updateInfo);
    
    // Set the default faces if the user hasn't added any yet
    if (localStorage['faces'] == undefined) face.reset();
    
    // Load faces onto the page!
    window.userFaces = JSON.parse(localStorage['faces']);
    
    var displayFaces = "";
    
    $.each(window.userFaces, function(id, text) {
	displayFaces += "<div>"+text+"</div>";   
    });
    
    $("#faces").append(displayFaces);
    
    // Check the user's settings
    options.check();
    
    // Show debug mode if enabled
    if (window.debug == 1) $("#debug").show();
    
    // Put current version in debug menu
    $("#debugVersion").text(window.version);
    
});



// Section 2: Class- face (add, del, suggestions, update, reset)
var face = {
 
    add: function(a) {
	
	// Check if this was submitted via the New Face or Suggestions box
	var newFace = ($(a).attr("id") == "addForm") ? $("#newFace").val() : $("#addSuggestions").val();
	
	// Make sure text was entered
	if (newFace == "") {
	    $("#errorExists").text("You didn't enter any text!");
	    return false;
	}
	
	// Check if already exists
	if (jQuery.inArray(newFace, JSON.parse(localStorage['faces'])) != -1) {
	    $("#errorExists").text(newFace+" already exists!");
	    return false;
	}
	
	// Add new face to the page
	$("#faces").append('<div class="editFaces">'+newFace+'</div>');
	
	
	// Update storage with current faces on page
	this.update();
	
	// Update the suggestions list
	face.suggestions();
	
	// Clear fields
	$("#newFace").val("");
	$("#errorExists").empty();
	
	return true;
	
    },
    
    del: function(a) {
	
	// Remove selected face from the page
	$(a).remove();
	
	// Update faces list
	this.update();
	
    },
    
    suggestions: function() {
	
	// Clear current suggestions list to keep it dynamic
	$("#addSuggestions").empty();
	
	var displaySugs = "";
    
	// Combine the defaults and suggestions
	var fullList = window.defaults.concat(window.suggestions);
    
	// Remove any faces that are already being used
	$.each(fullList, function(id, text) {
	    
	    if (jQuery.inArray(text, window.userFaces) == -1)
		displaySugs += "<option value='"+text+"'>"+text+"</option>";
	
	});
	
	// Show the suggestions
	if (displaySugs != "") {
	    $("#addSug").show();
	    $("#noSug").hide();
	    $("#addSuggestions").append(displaySugs);
	    
	} else {
	    // Hide the suggestions box if there is nothing to suggest.
	    $("#addSug").hide();
	    $("#noSug").show();
	}
	
    },
    
    update: function(a) {
	
	// Start an array of the faces
	var faces = [];
	
	// Go through all currently used faces and put them into the array
	$("#faces div").each(function(id) {
	    faces.push($(this).text());
	});
	
	// Update user's data with the current list of faces
	localStorage['faces']=JSON.stringify(faces);
	
	// update the userFaces variable
	window.userFaces = JSON.parse(localStorage['faces']);
	
    },
    
    reset: function() {
	
	// This function is only ran if this is the first time the extension has been loaded or the debug feature has been used.
	localStorage['faces'] = JSON.stringify(window.defaults);
	
    }
    
}


// Section 2: Class- edit (check, enable, disable, change)
// Enable/disable edit mode and change add/delete modes.
var edit = {
    
    // Check which mode the user is in, and put them in the opposite
    check: function() {
	
	if (window.editMode == "none")
	    this.enable();
	else
	    this.disable();
	    
    },
    
    // Enable edit mode
    enable: function() {
	
	// Hide instructions box
	$("#instructions").hide();
	
	// Show the edit mode boxes
	$(".inEdit").slideDown("normal");
	
	// Add editFaces class to each current face
	$("#faces div").addClass("editFaces");
	
	// Always put user in Add mode by default
	$("#add").trigger("click"); // Pretend like the Add button was clicked
	
	// Change the edit button to say Done
	$("#edit").html('<img src="assets/icons/accept.png" alt="" /> Done');
	
    },
    
    // Disable edit mode
    disable: function() {
	
	// Let the extension know we're no longer in edit mode
	window.editMode = "none";
	
	// Hide the edit mode boxes
	$(".inEdit").slideUp("normal");
	
	// Remove the editFaces class from all faces
	$("#faces div").removeClass("editFaces");
	
	// If the user wants to see instructions, show them again
	if (localStorage['optionInstructions'] == 1) $("#instructions").slideDown("normal");
	
	// Disable sorting of faces
	$("#faces").sortable("disable").enableSelection();
	
	// Put the edit button back to normal
	$("#edit").html('<img src="assets/icons/pencil.png" alt="" /> Edit');
	
    },
    
    // Change between Add and Delete mode
    change: function(a) {
	
	// See which mode was selected
	var thisMode = $(a).attr("id");
	
	// Tell extension which mode we are now in
	window.editMode = thisMode;
	
	// Remove changeMode from whatever was currently selected
	$("span.changeMode").removeClass("modeSelected");
	
	// Hide all current text about which mode the user was in
	$("div.modeInfo").hide();
	
	
	// Make changes based on which mode was selected
	// Note: The reason this is a switch instead of an if/else is because there used to be three modes until I combined Sort and Add. I kept it a switch so more modes can be quickly added later.
	switch(thisMode) {
	    
	    case "add":
		
		// Show updated list of suggestions
		face.suggestions();
		
		// Enable sorting
		$("#faces").sortable("enable"); // Have to do this apparently
		$("#faces").sortable({ 
		    stop: function(e, ui) {
			face.update();
		    }
		}).disableSelection();
		
	    break;
	
	    case "delete":
		
		// Just disable sorting
		$("#faces").sortable("disable");
		
	    break;
	    
	}
	
	// Add a class to the mode button that was selected
	$("#"+thisMode).addClass("modeSelected");
	
	// Show information about which mode was selected
	$("#modeInfo"+thisMode).show();
    }
    
}



// Section 04: Class- Options (check, update)
var options = {
    
    // Check user's settings at start up
    check: function() {
	
	// Set defaults if they are not defined yet
	if (localStorage['optionWidth'] == undefined) localStorage['optionWidth'] = "400px";
	if (localStorage['optionSize'] == undefined) localStorage['optionSize'] = "16px";
	if (localStorage['optionInstructions'] == undefined) localStorage['optionInstructions'] = 1;
	
	// Set popup width
	$("body,#faces").width(localStorage['optionWidth']);
	$("#optionWidth").val(localStorage['optionWidth']);
    
	// Set face size
	$("#faces").css("font-size", localStorage['optionSize']);
	$("#optionSize").val(localStorage['optionSize']);
	
	// Set instructions toggle
	if (localStorage['optionInstructions'] == 0) {
	    $("#instructions").hide();
	    $("#optionInstructions").prop("checked", false);
	}
    
    },
    
    update: function() {
	
	// Instructions box
	localStorage['optionInstructions'] = ($("#optionInstructions").prop("checked") == true) ? 1 : 0;
	if (localStorage['optionInstructions'] == 0) $("#instructions").hide();
	
	// Popup width
	var thisWidth = $("#optionWidth").val();
	$("body,#faces").width(thisWidth);
	localStorage['optionWidth'] = thisWidth;
	
	// Face size
	var thisSize = $("#optionSize").val();
	$("#faces").css("font-size", thisSize);
	localStorage['optionSize'] = thisSize;
	
    }
    
}



// Section 05: Keyboard Shortcuts
$(document).on("keyup", function(e){

    var keyPressed = e.keyCode;
    //console.log(keyPressed); // Enable this to test out new keybindings
   
    if (keyPressed == 69) { // Press E to toggle Edit Mode
	edit.check();
	return false;
    } else if (keyPressed == 68) { // Press D to toggle Debug Mode
	$("#debug").fadeToggle();
    }
    
    // Only allow keys 0-9 (0 will default to 10) when not in Edit Mode
    if (window.editMode != "none" || keyPressed < 48 || keyPressed > 57) return false;
    
    if (keyPressed != 48) {
        var trueKey = keyPressed - 49;
    } else {
        var trueKey = 9; // Actually 10
    }
    
    $("#faces div:eq("+trueKey+")").selectText();
    
});




// Section 06: Events

// Add face/suggestion button is clicked
$(document).on("submit", "#addForm,#addSug", function(e) { face.add($(this)); return false; });

// Edit/Done button clicked
$(document).on("click", "#edit", function() { edit.check(); });
    
// Change mode clicked
$(document).on("click", "span.changeMode", function() { edit.change($(this)); });

// Options changed
$(document).on("change", "#optionInstructions,#optionWidth,#optionSize", function(e) { options.update(); });

// When a face is clicked on...
$(document).on("click", "#faces div", function() {
    
    // If not in edit mode, select text
    if (window.editMode == "none") $(this).selectText();
    
    // If in delete mode, delete the face
    if (window.editMode == "delete") face.del($(this));
    
});

// Hide update info link clicked
$(document).on("click", "#hideUpdate", function() {
   localStorage['hideUpdate'] = 1;
   $("#update").fadeOut("slow");
});




// Section 98: Debug functions

$(document).on("click", "#debugClearStorage", function(e) {
    localStorage.clear();
    $("#debug").append(" REFRESH! ");
});

$(document).on("click", "#debugRestoreFaces", function() {
    face.reset();
    $("#debug").append(" REFRESH! ");
});


// Section 99: jQuery Plugins

// Thanks to Jason at StackOverflow for this (http://stackoverflow.com/users/7173/jason)
jQuery.fn.selectText = function(){
    var doc = document;
    var element = this[0];
    //console.log(this, element);
    if (doc.body.createTextRange) {
        var range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        var selection = window.getSelection();
        if (selection.setBaseAndExtent) {
            selection.setBaseAndExtent(element, 0, element, 1);
        } else {
            var range = document.createRange();
            range.selectNodeContents(element);
            selection.removeAllRanges();
            selection.addRange(element);
        }
    }
};


var promo_shown = localStorage.promo_shown_locomojis == "true";
var support_enabled = localStorage.support == "true";

if (!promo_shown && support_enabled) {
	$("#promotion").show();
}

$("#closePromotion").click(function () {
	localStorage.promo_shown_locomojis = "true";
	$("#promotion").fadeOut("slow");
});

$("#promotionLink").on('mousedown', function () {
	localStorage.promo_shown_locomojis = "true";
	$("#promotion").fadeOut("slow");
});
