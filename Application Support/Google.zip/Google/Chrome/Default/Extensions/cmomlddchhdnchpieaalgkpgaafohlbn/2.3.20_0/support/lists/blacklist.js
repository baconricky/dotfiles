
p180_blacklist = {
  "paypal.com":1, "xoom.com":1, "westernunion.com":1, 
  "facebook.com":1, "twitter.com":1, "gizmodo.com":1, "pintrest.com":1, "techcrunch.com":1, "engadget.com":1, "reddit.com":1, "digg.com":1, "imgur.com":1, "9gag.com":1, 
  "google.com":1, "youtube.com":1, "feedburner.com":1, "okut.com":1, "panoramio.com":1, "picnik.com":1, 
  "gamelink.com":1, "tianya.cn":1, "aastocks.com":1, "pvponline.com":1, "ettoday.net":1, "cnblogs.com":1, "cbs8.com":1, "ithome.com":1, "tvduck.com":1, "ifeng.com":1
};
