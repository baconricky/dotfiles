
chrome.tabs.getSelected ( null, function  ( tab ) { 

if ( tab.url.substring (0,4) != 'http' )
{
  document.getElementById("data").innerHTML = '<div class="mobilecenterbox"><fieldset><p>Click on this extension when you are on pages like <a href=http://google.com target=_blank>google.com</a>.</p></fieldset></div>';
} else {

  var xhr = new XMLHttpRequest();
  xhr.open("GET", "http://builtwith.com/mobile.aspx?" + tab.url, true);

  xhr.send();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      document.getElementById("data").innerHTML = xhr.responseText;
	    
	    
if ( document.getElementById('adv')!=null ) {	    
   document.getElementById('adv').addEventListener('click',function(){advanced('http://builtwith.com/app/mobile/advanced.aspx')},false);
   }
   
   if ( document.getElementById('advl')!=null )
   {
document.getElementById('advl').addEventListener('click',function(){advanced(document.getElementById('advl').href)},false);	   
   }
    }
  }

}

} );
var BW={};

advanced = function (u)
{
	  var xhr = new XMLHttpRequest();
  xhr.open("GET", u, true);

  xhr.send();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      document.getElementById("data").innerHTML = xhr.responseText;
	    if ( document.getElementById('detailed') != null )
	    document.getElementById('detailed').addEventListener('click',function(){advanced('http://builtwith.com/app/mobile/detailed.aspx?optimizely.com')},false);
	    else {
		    var s = document.createElement('script');
		    
s.src = chrome.extension.getURL('bw.min.js');
(document.head||document.documentElement).appendChild(s);
s.onload = function() {
    s.parentNode.removeChild(s);
};
	    }
    }
  }
}


