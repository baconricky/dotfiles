Panel View for Play Music
==========

Panelized extension for Google Music.

After you download the zip, extract it to the folder location of your choice on your hard drive.
In Chrome, click the menu button > Tools > Extensions. In the top right corner, make sure "Developer mode" is checked. Click the "Load unpacked extension" button. Navigate to the extension's folder, click it to select it, and click OK.
That should do it; the Keep icon should appear next to the URL bar. Right click the icon for settings, etc. etc.
Enjoy!
