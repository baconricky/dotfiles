
var debug = false;

chrome.browserAction.onClicked.addListener(
  function(tab) {
    
    debug = !debug;
    
    chrome.browserAction.setTitle({
      title: debug ? 'SiteCat debugger is ON' : 'SiteCat debugger is OFF'
    });
    
    chrome.browserAction.setIcon({
      path: debug ? 'icon128.png' : 'icon128off.png'
    });
    
    //chrome.tabs.update(tab.id, {url: tab.url, selected: tab.selected}, null);
    //chrome.webRequest.handlerBehaviorChanged();
  
  }
);


chrome.webRequest.onBeforeRequest.addListener(
	function(details) {   
		if (debug) { 
        	chrome.tabs.query({active: true, currentWindow: true},function(tabs) {
	        	chrome.tabs.sendMessage(tabs[0].id, details.url);
	        });
	    }
    },  
	{ urls: ["*://*/b/ss/*"] }
);
