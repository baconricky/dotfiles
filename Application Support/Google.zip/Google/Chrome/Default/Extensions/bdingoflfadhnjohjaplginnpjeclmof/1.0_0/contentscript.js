
var formatSiteCatPixel = {
		
	output: '',
	path: null,
	params: null,
	query: {},
	no: 1,	
	
	init: function(url) {
	
		this.path = url.split('/');
		this.params = url.split('?')[1].split('&');
		
		this.setQuery(url);
		
		this.header(url);
		this.mainBody();
		this.footer();
		
		console.log(this.output);
		this.output = '';
		this.no++;
	},
	
	setQuery: function(url) {
		params = url.split('?')[1].split('&');
		for (var k in params) {
			if (params.hasOwnProperty(k)) {	
				tmp = params[k].split('=');
				this.query[tmp[0]] = tmp[1];		
			}
		}
	},
	
	header: function(url) {
		this.output = this.output + "\nSiteCatalyst Server Call #" + this.no + " (" + url.length + " chars)\n";
		
		if(this.query['pe']) {
			types = {
				'lnk_o' : 'CUSTOM LINK',
				'lnk_e' : 'EXIT LINK',
				'lnk_d' : 'DOWNLOAD LINK'
			}
			this.output = this.output + types[this.query['pe']] + Array(20-types[this.query['pe']].length).join(' ') + ': ' + unescape(this.query['pev2']) + "\n";
		}
		
		this.output = this.output + "Report Suite ID    : " + this.path[5] + "\n";
	},
	
	mainBody: function() {
		for (var k in this.dict) {
			if (this.dict.hasOwnProperty(k)) {
				for(var k1 in this.params) {
					if(this.params.hasOwnProperty(k1)) {
						param = this.params[k1].split('=');	
						if(param[0].match('^'+k+'$')) {
							
							key = this.dict[k] + (this.dict[k].match(/eVar|prop/) ? param[0].match(/[0-9]{1,2}/)[0] : '');
							value = k=='products' ? this.getProducts(param[1]) : unescape(param[1]);
							
							this.output = this.output + key + Array(20-key.length).join(' ') + ': ' + value + '\n';
							delete this.params[k1];
						}	
					}
				}
			}
		}
	},
	
	getProducts: function(products) {
				
		dictProducts = {
			0: 'Category   : ',
			1: 'Product    : ',
			2: 'Quantity   : ',
			3: 'Price      : ',
			4: 'Events     : ',
			5: 'eVars      : '
		}
		
		format = '\n';
		products = unescape(products).split(',');
		for (var i=0; i<products.length; i++) {
			format = format + (i==0?'':'\n') + '    #' + (i+1) + '\n';
			item = products[i].split(';');
			for (var y=0; y<item.length; y++) {
				if(item[y])
					format = format + '    ' + dictProducts[y] + item[y] + '\n';
			}
		}
		
		return format; 
	},

	footer: function() {
		var dc = '';
		for (var k in this.dataCenters) {
			if (this.dataCenters.hasOwnProperty(k)) {				
				if(this.path[2].match(k)) {
					dc = ' - ' + this.dataCenters[k];
					break;
				}
			}
		}
	
		this.output = this.output + "Version of Code    : " + this.path[7] + "\n";
		this.output = this.output + "Data Centre        : " + this.path[2] + dc +"\n";	
	},	

	dict: {
		'pageName'		: 'Page Name',
		'ch'			: 'Site Section',
		'server'		: 'Server',
		'g'				: 'Current URL',
		'events'		: 'Events',
		'purchaseID'	: 'Purchase ID',	
		'products'		: 'Products',
		'v0'			: 'Campaign',
		'v([0-9]{1,2})'	: 'eVar',
		'c([0-9]{1,2})'	: 'prop',
		'xact'			: 'Transaction ID',
		'cc'			: 'Currency Code',
		'ce'			: 'Char Set',
		's'				: 'Screen Resolution',
		'c'				: 'Color Depth',
		'j'				: 'JavaScript Version',
		'v'				: 'JavaScript Enabled',
		'k'				: 'Cookies Supported',
		'bw'			: 'Browser Width',
		'bh'			: 'Browser Height'
		//'p'				: 'Plug-ins'
	},
	
	dataCenters: {
		'112.2o7.net' 	   : 'San Jose, California (old data collection method)',
		'122.2o7.net'	   : 'Dallas, Texas (old data collection method)',
		'd1.sc.omtrdc.net' : 'San Jose, California',
		'd2.sc.omtrdc.net' : 'Dallas, Texas',
		'd3.sc.omtrdc.net' : 'London, United Kingdom'
	}
}

chrome.extension.onMessage.addListener(
	function(request, sender, sendResponse) {
		formatSiteCatPixel.init(request);
	}
);

