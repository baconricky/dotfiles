// @license Copyright (C) 2012 Observepoint LLC. All rights reserved.

var tagListener = document.getElementById('tag_listener');
tagListener.addEventListener('load', moduleDidLoad, true);
tagListener.addEventListener('message', handleTag, true);
