pref("extensions.lastpass.username", "");
