module PostgresPR
  Version = "0.4.0"
end
