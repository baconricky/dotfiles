# TextMate Tomorrow Theme
The TextMate version of [Tomorrow Theme](https://github.com/ChrisKempson/Tomorrow-Theme).

## Take a look!
Tomorrow theme variations in shown in TextMate with Ruby code.
<table border="0" cellspacing="5" cellpadding="5">
	<tr>
		<td>Tomorrow Night<br><img src="https://github.com/ChrisKempson/TextMate-Tomorrow-Theme/raw/master/Images/Tomorrow-Night.png"/></td>
		<td>Tomorrow      <br><img src="https://github.com/ChrisKempson/TextMate-Tomorrow-Theme/raw/master/Images/Tomorrow.png"/></td>
	</tr>
	<tr>
		<td>Tomorrow Night Eighties <br><img src="https://github.com/ChrisKempson/TextMate-Tomorrow-Theme/raw/master/Images/Tomorrow-Night-Eighties.png"/></td>
		<td>Tomorrow Night Blue     <br><img src="https://github.com/ChrisKempson/TextMate-Tomorrow-Theme/raw/master/Images/Tomorrow-Night-Blue.png"/></td>
	</tr>
	<tr>
		<td>Tomorrow Night Bright   <br><img src="https://github.com/ChrisKempson/TextMate-Tomorrow-Theme/raw/master/Images/Tomorrow-Night-Bright.png"/></td>
		<td>&nbsp;</td>
	</tr>
</table>
