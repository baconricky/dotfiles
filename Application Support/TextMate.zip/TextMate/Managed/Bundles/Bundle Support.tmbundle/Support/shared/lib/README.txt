# Updated: 2005-05-20, Sune Foldager.

This directory should contain object files that aren't supposed to be executed directly,
such as shared libraries and bash source-files. Data files should not be here.
